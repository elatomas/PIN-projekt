﻿CREATE TABLE [dbo].[Baza_Filmova] (
    [FilmId]      INT IDENTITY(1,1)           NOT NULL,
    [Naziv]       VARCHAR (MAX) NULL,
    [Zanr]        VARCHAR (MAX) NULL,
    [DatumObjave] DATETIME      NULL,
    [Redatelj]    VARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([FilmId] ASC)
);

