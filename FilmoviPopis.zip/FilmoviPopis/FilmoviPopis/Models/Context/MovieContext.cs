﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace FilmoviPopis.Models.Context
{
    public partial class MovieContext : DbContext
    {
        public MovieContext()
        {
        }

        public MovieContext(DbContextOptions<MovieContext> options)
            : base(options)
        {
        }

        public virtual DbSet<BazaFilmova> BazaFilmova { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=.\\sqlexpress;Database=Film;Trusted_Connection=True;MultipleActiveResultSets=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BazaFilmova>(entity =>
            {
                entity.HasKey(e => e.FilmId)
                    .HasName("PK__tmp_ms_x__6D1D217C2692CAF2");

                entity.ToTable("Baza_Filmova");

                entity.Property(e => e.FilmId).ValueGeneratedNever();

                entity.Property(e => e.DatumObjave).HasColumnType("datetime");

                entity.Property(e => e.Naziv).IsUnicode(false);

                entity.Property(e => e.Redatelj).IsUnicode(false);

                entity.Property(e => e.Zanr).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
