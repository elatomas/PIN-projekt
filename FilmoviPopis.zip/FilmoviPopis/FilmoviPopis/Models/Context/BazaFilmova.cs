﻿using System;
using System.Collections.Generic;

namespace FilmoviPopis.Models.Context
{
    public partial class BazaFilmova
    {
        public int FilmId { get; set; }
        public string Naziv { get; set; }
        public string Zanr { get; set; }
        public DateTime? DatumObjave { get; set; }
        public string Redatelj { get; set; }
    }
}
