﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FilmoviPopis.Models.Context;

namespace FilmoviPopis.Controllers
{
    public class BazaFilmovasController : Controller
    {
        private readonly MovieContext _context;

        public BazaFilmovasController(MovieContext context)
        {
            _context = context;
        }

        // GET: BazaFilmovas
        public async Task<IActionResult> Index()
        {
            return View(await _context.BazaFilmova.ToListAsync());
        }

        // GET: BazaFilmovas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bazaFilmova = await _context.BazaFilmova
                .FirstOrDefaultAsync(m => m.FilmId == id);
            if (bazaFilmova == null)
            {
                return NotFound();
            }

            return View(bazaFilmova);
        }

        // GET: BazaFilmovas/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: BazaFilmovas/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FilmId,Naziv,Zanr,DatumObjave,Redatelj")] BazaFilmova bazaFilmova)
        {
            if (ModelState.IsValid)
            {
                _context.Add(bazaFilmova);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(bazaFilmova);
        }

        // GET: BazaFilmovas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bazaFilmova = await _context.BazaFilmova.FindAsync(id);
            if (bazaFilmova == null)
            {
                return NotFound();
            }
            return View(bazaFilmova);
        }

        // POST: BazaFilmovas/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("FilmId,Naziv,Zanr,DatumObjave,Redatelj")] BazaFilmova bazaFilmova)
        {
            if (id != bazaFilmova.FilmId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(bazaFilmova);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BazaFilmovaExists(bazaFilmova.FilmId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(bazaFilmova);
        }

        // GET: BazaFilmovas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bazaFilmova = await _context.BazaFilmova
                .FirstOrDefaultAsync(m => m.FilmId == id);
            if (bazaFilmova == null)
            {
                return NotFound();
            }

            return View(bazaFilmova);
        }

        // POST: BazaFilmovas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var bazaFilmova = await _context.BazaFilmova.FindAsync(id);
            _context.BazaFilmova.Remove(bazaFilmova);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BazaFilmovaExists(int id)
        {
            return _context.BazaFilmova.Any(e => e.FilmId == id);
        }
    }
}
